import 'package:flutter/material.dart';

class AppTexts {

  static double small = 12;
   static double normal = 18;
   static double large = 35;
}

class AppColors {

  static Color main = const Color.fromARGB(255, 65, 205, 240);
}